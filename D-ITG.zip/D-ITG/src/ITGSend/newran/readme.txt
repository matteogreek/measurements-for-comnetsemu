Newran03 C++ random number generator library.

Documentation is in nr03doc.htm.

